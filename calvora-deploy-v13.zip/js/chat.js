/* CALVORA help chat. Free: answers come from the site's own text, no AI service and no cost. */
(function () {
  "use strict";
  if (window.__cvchat) return; window.__cvchat = 1;
  var S = window.SITE || {}, CV = window.CV, O = S.office || {};
  var FAQ = [
    ["How do I know a property is verified?", "A property is called verified only after four checks are on record: the agent's identity, a team visit to the property, the owner's permission to advertise, and recently confirmed details. Look for the Verification Completed label. See how we verify on about.html."],
    ["How do I list my property?", "Owners can send us the details and proof of ownership or permission to let or sell. Our team checks the property before it goes live. Start on list-property.html."],
    ["I want to become an agent", "Create an account and apply on agent.html. You send your details and ID, agree to our code of conduct, and our team reviews your application."],
    ["Someone asked me to pay. Is it safe?", "Never pay for a property you have not inspected. Check the agent's ID on verify.html, pay only to the official Calvora account by bank transfer, and ask for every fee in writing. Read safety.html, and report anything suspicious on complaints.html."],
    ["Help me find a property", "Tell us what you need on requests.html. You can post a public request or ask our personal concierge to search for you. You can also browse rent.html, buy.html and lands.html."]
  ];
  var KW = [
    [/verif|genuine|real|fake|scam/i, 0],
    [/list|landlord|owner|my (house|property|land)|sell my/i, 1],
    [/agent|apply|join|badge/i, 2],
    [/pay|payment|transfer|account|deposit|money|fraud/i, 3],
    [/find|looking|need|search|want|budget|bedroom|flat|room|apartment|house|land|plot|rent|buy/i, 4],
    [/fee|fees|cost|charge|commission|caution|agreement/i, "Every fee (agency, legal, caution and any other charge) should be shown on the listing and explained to you in writing before you pay. If a fee is not on the listing, ask the agent or message us. Never pay before you inspect. See safety.html."],
    [/inspect|visit|view|see the (house|property)/i, "You can book an inspection from any property page. Never pay for a property you have not inspected. A genuine agent will happily show you."],
    [/complain|report|problem|issue|cheat/i, "You can report a problem on complaints.html. Every complaint gets a reference number and is investigated."],
    [/partner|developer|estate firm|surveyor|lawyer/i, "We work with owners, developers, agents, property managers and professionals. See partners.html and send a short enquiry."],
    [/contact|call|phone|whatsapp|email|office|address|talk|human|person/i, "You can reach the Calvora team on WhatsApp or by phone on +234 904 747 0202, or by email at calvoraproperties@gmail.com. See contact.html."]
  ];
  function answer(q) {
    for (var i = 0; i < KW.length; i++) if (KW[i][0].test(q)) return typeof KW[i][1] === "number" ? FAQ[KW[i][1]][1] : KW[i][1];
    return "I am not sure about that one. The team can help directly. You can also post what you need on requests.html or read about.html.";
  }
  var css = '.cvc-b{position:fixed;right:16px;bottom:16px;z-index:90;display:flex;align-items:center;gap:8px;background:var(--navy);color:var(--white);border:2px solid var(--green);border-radius:999px;padding:12px 18px;font:inherit;font-weight:700;cursor:pointer;box-shadow:0 6px 20px rgba(1,37,71,.28)}.cvc-b:hover{background:var(--navy-deep)}' +
    '.cvc-p{position:fixed;right:16px;bottom:16px;z-index:91;width:min(380px,calc(100% - 32px));height:min(560px,calc(100% - 32px));background:var(--white);border:1.5px solid var(--navy);border-radius:var(--r);display:none;flex-direction:column;overflow:hidden;box-shadow:0 12px 36px rgba(1,37,71,.3)}.cvc-p.open{display:flex}' +
    '.cvc-h{background:var(--navy);color:var(--white);padding:12px 14px;display:flex;justify-content:space-between;align-items:center;gap:8px}.cvc-h b{font-family:var(--display)}.cvc-h small{display:block;color:#D3E0EC}.cvc-x{background:transparent;border:1.5px solid var(--green);color:var(--white);border-radius:999px;padding:4px 12px;font:inherit;font-weight:700;cursor:pointer}' +
    '.cvc-m{flex:1;overflow:auto;padding:14px;display:flex;flex-direction:column;gap:10px;background:var(--mist)}.cvc-m div.m{max-width:88%;padding:10px 13px;border-radius:14px;white-space:pre-line;font-size:.95rem}.cvc-m .a{background:var(--white);border:1.5px solid var(--line);align-self:flex-start}.cvc-m .u{background:var(--navy);color:var(--white);align-self:flex-end}.cvc-m a{color:var(--green-deep);font-weight:700}.cvc-m .u a{color:var(--green)}' +
    '.cvc-c{display:flex;flex-wrap:wrap;gap:6px}.cvc-c button{background:var(--white);border:1.5px solid var(--navy);color:var(--navy);border-radius:999px;padding:6px 12px;font:inherit;font-size:.85rem;font-weight:600;cursor:pointer;text-align:left}.cvc-c button:hover{background:var(--navy-soft)}' +
    '.cvc-f{display:flex;gap:8px;padding:10px;border-top:1.5px solid var(--line);background:var(--white)}.cvc-f input{flex:1;margin:0}.cvc-n{padding:0 12px 10px;background:var(--white)}';
  var st = document.createElement("style"); st.textContent = css; document.head.appendChild(st);
  var btn = document.createElement("button"); btn.type = "button"; btn.className = "cvc-b"; btn.setAttribute("aria-haspopup", "dialog"); btn.innerHTML = "Need help?";
  var p = document.createElement("div"); p.className = "cvc-p"; p.setAttribute("role", "dialog"); p.setAttribute("aria-label", "Calvora help");
  p.innerHTML = '<div class="cvc-h"><div><b>Calvora help</b><small>Ask about renting, buying and listing</small></div><button type="button" class="cvc-x">Close</button></div><div class="cvc-m" id="cvcm" aria-live="polite"></div>' +
    '<form class="cvc-f"><label class="sr" for="cvci">Your question</label><input id="cvci" maxlength="300" autocomplete="off" placeholder="Type your question"><button class="btn sm" type="submit">Send</button></form><div class="cvc-n fine">Automatic help. It cannot confirm availability or take payment. Never pay before inspecting.</div>';
  document.body.appendChild(btn); document.body.appendChild(p);
  var box = p.querySelector("#cvcm"), form = p.querySelector("form"), inp = p.querySelector("#cvci"), hist = [];
  try { hist = JSON.parse(sessionStorage.getItem("cvchat") || "[]"); } catch (e) {}
  function fmt(t) { return CV.esc(t).replace(/\*\*(.+?)\*\*/g, "<b>$1</b>").replace(/\b([a-z-]+\.html)\b/g, '<a href="$1">$1</a>'); }
  function add(role, text) { var d = document.createElement("div"); d.className = "m " + (role === "user" ? "u" : "a"); d.innerHTML = fmt(text); box.appendChild(d); box.scrollTop = box.scrollHeight; return d; }
  function save() { try { sessionStorage.setItem("cvchat", JSON.stringify(hist.slice(-12))); } catch (e) {} }
  function wa() { var l = CV.waLink("Hello CALVORA, I have a question."); return l ? '\n\nOr message us on <a href="' + CV.esc(l) + '" rel="noopener">WhatsApp</a>.' : ""; }
  function chips() { var c = document.createElement("div"); c.className = "cvc-c"; FAQ.forEach(function (f) { var b = document.createElement("button"); b.type = "button"; b.textContent = f[0]; b.onclick = function () { c.remove(); add("user", f[0]); add("assistant", f[1]); hist.push({ role: "user", content: f[0] }, { role: "assistant", content: f[1] }); save(); }; c.appendChild(b); }); box.appendChild(c); }
  function start() { if (hist.length) { hist.forEach(function (m) { add(m.role, m.content); }); } else { add("assistant", "Hello, I am the Calvora help. I can explain how verification works, how to list a property or become an agent, and how to stay safe. What would you like to know?"); chips(); } }
  var started = false;
  function open() { p.classList.add("open"); btn.style.display = "none"; if (!started) { started = true; start(); } inp.focus(); }
  function close() { p.classList.remove("open"); btn.style.display = ""; btn.focus(); }
  btn.onclick = open; p.querySelector(".cvc-x").onclick = close;
  p.addEventListener("keydown", function (e) { if (e.key === "Escape") close(); });
  form.addEventListener("submit", function (e) {
    e.preventDefault(); var q = inp.value.trim(); if (!q) return;
    inp.value = ""; add("user", q); var a = answer(q); var d = add("assistant", a);
    if (a.indexOf("not sure") === 0) d.innerHTML += wa();
    hist.push({ role: "user", content: q }, { role: "assistant", content: a }); save();
  });
})();
