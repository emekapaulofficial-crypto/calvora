-- CALVORA: property request board + personal concierge. Run once in Supabase > SQL Editor.
create sequence if not exists property_request_seq;
create table if not exists public.property_requests (
  id uuid primary key default gen_random_uuid(),
  code text unique not null,
  kind text not null check (kind in ('board','concierge')),
  name text not null default '',
  phone text not null,
  listing_type text not null check (listing_type in ('rent','buy','land')),
  property_type text not null default '',
  area text not null default '',
  budget_max numeric,
  bedrooms int,
  details text not null default '',
  status text not null default 'new' check (status in ('new','approved','matched','closed','rejected')),
  staff_note text not null default '',
  created_at timestamptz not null default now()
);
alter table public.property_requests enable row level security;  -- no public policies: the table itself stays private

create or replace function public.submit_property_request(
  p_kind text, p_name text, p_phone text, p_listing_type text, p_property_type text,
  p_area text, p_budget numeric, p_bedrooms int, p_details text)
returns text language plpgsql security definer set search_path = public as $$
declare v_code text;
begin
  if p_kind not in ('board','concierge') then raise exception 'Please choose a request type.'; end if;
  if p_listing_type not in ('rent','buy','land') then raise exception 'Please choose rent, buy or land.'; end if;
  if length(regexp_replace(coalesce(p_phone,''), '\D', '', 'g')) < 10 then raise exception 'Please enter a phone number we can reach you on.'; end if;
  if length(trim(coalesce(p_area,''))) < 2 then raise exception 'Please tell us the area you want.'; end if;
  v_code := 'CV-R-' || lpad(nextval('property_request_seq')::text, 5, '0');
  insert into property_requests(code, kind, name, phone, listing_type, property_type, area, budget_max, bedrooms, details)
  values (v_code, p_kind, left(coalesce(p_name,''),100), left(p_phone,30), p_listing_type, left(coalesce(p_property_type,''),60),
          left(p_area,120), p_budget, p_bedrooms, left(coalesce(p_details,''),1000));
  return v_code;
end $$;
grant execute on function public.submit_property_request(text,text,text,text,text,text,numeric,int,text) to anon, authenticated;

-- What the public board may see: approved board requests only, never name or phone.
create or replace view public.public_requests as
  select code, listing_type, property_type, area, budget_max, bedrooms, details, created_at
  from public.property_requests where kind = 'board' and status = 'approved';
grant select on public.public_requests to anon, authenticated;
-- Staff: open Table Editor > property_requests, read new rows, and set status to 'approved' to show a board request.
