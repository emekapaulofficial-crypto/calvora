-- CALVORA: lets signed-in staff (admin, operations, marketing) read and handle property requests.
-- Run once in Supabase > SQL Editor, AFTER requests.sql.
create or replace function public.is_request_staff() returns boolean
language sql security definer stable set search_path = public as $$
  select exists (select 1 from public.profiles p
    where p.id = auth.uid() and p.status = 'active' and p.role in ('admin','staff'));
$$;
grant execute on function public.is_request_staff() to authenticated;

drop policy if exists "staff read requests" on public.property_requests;
create policy "staff read requests" on public.property_requests for select to authenticated using (public.is_request_staff());
drop policy if exists "staff update requests" on public.property_requests;
create policy "staff update requests" on public.property_requests for update to authenticated
  using (public.is_request_staff()) with check (public.is_request_staff());

-- Staff may change only the status and the private note.
revoke update on public.property_requests from authenticated;
grant update (status, staff_note) on public.property_requests to authenticated;
