-- =====================================================================
-- CALVORA PROPERTY SOLUTIONS: database upgrade
-- Runs ON TOP of the existing RentCheck schema (supabase/schema.sql).
-- Safe to run more than once. Run it in the Supabase SQL editor.
-- BEFORE YOU RUN IT: export a backup of your project's data.
-- Never put a service_role key in website code or in GitHub.
-- =====================================================================

create extension if not exists pgcrypto;

-- ---------------------------------------------------------------------
-- 0. Code sequences (agent IDs, staff IDs, property codes, complaint refs)
-- ---------------------------------------------------------------------
create sequence if not exists public.cv_agent_seq start 1;
create sequence if not exists public.cv_staff_seq start 1;
create sequence if not exists public.cv_property_seq start 1;
create sequence if not exists public.cv_complaint_seq start 1;

-- ---------------------------------------------------------------------
-- 1. profiles: staff role, codes, contact, photo, ID expiry
-- ---------------------------------------------------------------------
alter table public.profiles drop constraint if exists profiles_role_check;
alter table public.profiles add constraint profiles_role_check
  check (role in ('customer','agent','staff','admin'));
alter table public.profiles add column if not exists staff_role text;
alter table public.profiles drop constraint if exists profiles_staff_role_check;
alter table public.profiles add constraint profiles_staff_role_check
  check (staff_role is null or staff_role in ('operations','marketing'));
alter table public.profiles add column if not exists staff_code text;
alter table public.profiles add column if not exists phone text;
alter table public.profiles add column if not exists photo_url text;
alter table public.profiles add column if not exists location text;
alter table public.profiles add column if not exists id_expires_at timestamptz;
create unique index if not exists profiles_staff_code_key on public.profiles(staff_code) where staff_code is not null;

-- ---------------------------------------------------------------------
-- 2. properties: three catalogues (rent houses, sale houses, sale land)
-- ---------------------------------------------------------------------
alter table public.properties add column if not exists listing_type text not null default 'rent';
alter table public.properties add column if not exists category text not null default 'house';
alter table public.properties alter column listing_type drop default;
alter table public.properties alter column category drop default;
alter table public.properties add column if not exists price numeric(14,2);
update public.properties set price = rent_per_year where price is null;
alter table public.properties alter column price set not null;
alter table public.properties drop constraint if exists properties_price_check;
alter table public.properties add constraint properties_price_check check (price > 0);
alter table public.properties alter column rent_per_year drop not null;
alter table public.properties add column if not exists land_size_sqm numeric(14,2);
alter table public.properties add column if not exists land_title text;
alter table public.properties add column if not exists features text[] not null default '{}';
alter table public.properties add column if not exists last_confirmed_at timestamptz;
alter table public.properties add column if not exists listing_code text;
update public.properties set listing_code = 'CV-P-' || lpad(nextval('public.cv_property_seq')::text, 5, '0') where listing_code is null;
alter table public.properties alter column listing_code set default ('CV-P-' || lpad(nextval('public.cv_property_seq')::text, 5, '0'));
alter table public.properties alter column listing_code set not null;
create unique index if not exists properties_listing_code_key on public.properties(listing_code);
update public.properties set last_confirmed_at = coalesce(published_at, created_at) where last_confirmed_at is null and status = 'approved';

alter table public.properties drop constraint if exists properties_listing_type_check;
alter table public.properties add constraint properties_listing_type_check check (listing_type in ('rent','sale'));
alter table public.properties drop constraint if exists properties_category_check;
alter table public.properties add constraint properties_category_check check (category in ('house','land'));
alter table public.properties drop constraint if exists properties_land_sale_only;
alter table public.properties add constraint properties_land_sale_only check (category <> 'land' or listing_type = 'sale');
alter table public.properties drop constraint if exists properties_land_size_check;
alter table public.properties add constraint properties_land_size_check check (land_size_sqm is null or land_size_sqm > 0);
alter table public.properties drop constraint if exists properties_status_check;
alter table public.properties add constraint properties_status_check
  check (status in ('draft','pending_review','under_review','needs_changes','approved','rejected','hidden','rented','sold'));

create index if not exists properties_catalogue_idx on public.properties(status, listing_type, category, state, price);
create index if not exists properties_agent_status_idx on public.properties(agent_id, status);

-- keep the old rent_per_year column in step with price (old code still reads it)
create or replace function public.cv_sync_price() returns trigger language plpgsql as $$
begin
  new.rent_per_year := case when new.listing_type = 'rent' then new.price else null end;
  return new;
end; $$;
drop trigger if exists properties_sync_price on public.properties;
create trigger properties_sync_price before insert or update on public.properties
  for each row execute function public.cv_sync_price();

-- ---------------------------------------------------------------------
-- 3. New tables
-- ---------------------------------------------------------------------
create table if not exists public.property_owner_details (
  id uuid primary key default gen_random_uuid(),
  property_id uuid not null unique references public.properties(id) on delete cascade,
  relationship text not null default '',
  owner_name text not null check (length(trim(owner_name)) >= 2),
  owner_phone text not null default '',
  owner_email text,
  owner_address text not null default '',
  authorised boolean not null default false,
  proof_paths text[] not null default '{}',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.transactions (
  id uuid primary key default gen_random_uuid(),
  property_id uuid not null references public.properties(id) on delete restrict,
  agent_id uuid not null references public.profiles(id) on delete restrict,
  kind text not null check (kind in ('rent','sale')),
  customer_name text not null,
  customer_phone text not null default '',
  deal_value numeric(14,2) not null check (deal_value > 0),
  commission_amount numeric(14,2) not null check (commission_amount >= 0),
  agent_share numeric(14,2) not null check (agent_share >= 0),
  status text not null default 'completed' check (status in ('completed','cancelled')),
  notes text,
  recorded_by uuid references public.profiles(id) on delete set null,
  completed_at timestamptz not null default now(),
  created_at timestamptz not null default now(),
  check (agent_share <= commission_amount)
);
create unique index if not exists transactions_one_completed_per_property
  on public.transactions(property_id) where status = 'completed';
create index if not exists transactions_agent_idx on public.transactions(agent_id, completed_at desc);

alter table public.commissions add column if not exists transaction_id uuid references public.transactions(id) on delete set null;

create table if not exists public.agent_reviews (
  id uuid primary key default gen_random_uuid(),
  agent_id uuid not null references public.profiles(id) on delete cascade,
  property_id uuid references public.properties(id) on delete set null,
  reviewer_name text not null check (length(trim(reviewer_name)) between 2 and 80),
  reviewer_phone text not null default '',
  rating integer not null check (rating between 1 and 5),
  comment text not null default '' check (length(comment) <= 1000),
  verified boolean not null default false,
  created_at timestamptz not null default now()
);
create index if not exists agent_reviews_agent_idx on public.agent_reviews(agent_id, verified);

create table if not exists public.agent_weekly_reports (
  id uuid primary key default gen_random_uuid(),
  agent_id uuid not null references public.profiles(id) on delete cascade,
  week_start date not null,
  new_properties_sourced integer not null default 0 check (new_properties_sourced >= 0),
  owner_contacts integer not null default 0 check (owner_contacts >= 0),
  authorisations_obtained integer not null default 0 check (authorisations_obtained >= 0),
  listings_submitted integer not null default 0 check (listings_submitted >= 0),
  inspections_attended integer not null default 0 check (inspections_attended >= 0),
  enquiries_handled integer not null default 0 check (enquiries_handled >= 0),
  transactions_completed integer not null default 0 check (transactions_completed >= 0),
  problems text not null default '',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (agent_id, week_start)
);

create table if not exists public.weekly_reports (
  id uuid primary key default gen_random_uuid(),
  week_start date not null unique,
  active_agents integer not null default 0,
  active_properties integer not null default 0,
  enquiries integer not null default 0,
  inspections integer not null default 0,
  transactions integer not null default 0,
  revenue numeric(14,2) not null default 0,
  expenses numeric(14,2) not null default 0,
  issues text not null default '',
  created_at timestamptz not null default now()
);

create table if not exists public.site_settings (
  key text primary key,
  value text not null default ''
);

alter table public.complaints add column if not exists ref_code text;
update public.complaints set ref_code = 'CV-C-' || lpad(nextval('public.cv_complaint_seq')::text, 5, '0') where ref_code is null;
alter table public.complaints alter column ref_code set default ('CV-C-' || lpad(nextval('public.cv_complaint_seq')::text, 5, '0'));
alter table public.complaints alter column ref_code set not null;
create unique index if not exists complaints_ref_code_key on public.complaints(ref_code);

-- trigger: fill agent_id on a new inspection booking from the property
create or replace function public.cv_booking_agent() returns trigger language plpgsql security definer set search_path = public as $$
begin
  select agent_id into new.agent_id from public.properties where id = new.property_id;
  return new;
end; $$;
drop trigger if exists inspection_bookings_agent on public.inspection_bookings;
create trigger inspection_bookings_agent before insert on public.inspection_bookings
  for each row execute function public.cv_booking_agent();

drop trigger if exists owner_details_touch on public.property_owner_details;
create trigger owner_details_touch before update on public.property_owner_details for each row execute function public.rc_touch_updated_at();
drop trigger if exists agent_weekly_touch on public.agent_weekly_reports;
create trigger agent_weekly_touch before update on public.agent_weekly_reports for each row execute function public.rc_touch_updated_at();

-- ---------------------------------------------------------------------
-- 4. Role helpers
-- ---------------------------------------------------------------------
create or replace function public.rc_staff_role() returns text language sql stable security definer set search_path = public as $$
  select case when role = 'admin' then 'admin' when role = 'staff' then staff_role else null end
  from public.profiles where id = auth.uid() and status = 'active';
$$;
create or replace function public.rc_is_staff() returns boolean language sql stable security definer set search_path = public as $$
  select coalesce(public.rc_staff_role() is not null, false);
$$;
create or replace function public.rc_is_ops() returns boolean language sql stable security definer set search_path = public as $$
  select coalesce(public.rc_staff_role() in ('admin','operations'), false);
$$;

create or replace function public.rc_badge(p_listings integer, p_transactions integer, p_rating numeric) returns text language sql immutable as $$
  select case
    when p_listings >= 30 and p_transactions >= 10 and p_rating >= 4.7 then 'Diamond'
    when p_listings >= 15 and p_transactions >= 3 and p_rating >= 4.5 then 'Gold'
    when p_listings >= 5 and p_transactions >= 1 then 'Silver'
    else 'Bronze' end;
$$;

-- ---------------------------------------------------------------------
-- 5. Public views (public data only; no private tables exposed)
-- ---------------------------------------------------------------------
drop view if exists public.public_reviews;
drop view if exists public.public_properties;
drop view if exists public.public_agents;
drop view if exists public.agent_stats;

create view public.agent_stats as
select pr.id as agent_id,
  (select count(*) from public.properties p where p.agent_id = pr.id and p.status in ('approved','rented','sold'))::int as approved_listings,
  (select count(*) from public.transactions t where t.agent_id = pr.id and t.status = 'completed')::int as completed_transactions,
  coalesce((select round(avg(r.rating)::numeric, 2) from public.agent_reviews r where r.agent_id = pr.id and r.verified), 0) as avg_rating,
  (select count(*) from public.agent_reviews r where r.agent_id = pr.id and r.verified)::int as review_count
from public.profiles pr where pr.role = 'agent';

create view public.public_agents as
select pr.id, pr.agent_code, pr.full_name as name, pr.photo_url, pr.location, pr.created_at as joined_at,
  s.approved_listings, s.completed_transactions, s.avg_rating, s.review_count,
  public.rc_badge(s.approved_listings, s.completed_transactions, s.avg_rating) as badge
from public.profiles pr join public.agent_stats s on s.agent_id = pr.id
where pr.role = 'agent' and pr.status = 'active' and pr.agent_code is not null
  and (pr.id_expires_at is null or pr.id_expires_at > now());

create view public.public_properties as
select p.id, p.listing_code, p.listing_type, p.category, p.title, p.state, p.area, p.property_type,
  p.bedrooms, p.bathrooms, p.price, p.agency_fee, p.caution_fee, p.legal_fee,
  p.land_size_sqm, p.land_title, p.features, p.description, p.photo_urls, p.status,
  p.published_at, p.last_confirmed_at, p.created_at,
  (select count(distinct v.label) from public.verification_records v where v.property_id = p.id)::int as checks_recorded,
  pa.name as agent_name, pa.agent_code, pa.photo_url as agent_photo, pa.badge as agent_badge,
  coalesce(a.phone, pr.phone) as agent_phone, coalesce(a.whatsapp, a.phone, pr.phone) as agent_whatsapp
from public.properties p
join public.profiles pr on pr.id = p.agent_id
join public.public_agents pa on pa.id = p.agent_id
left join public.agent_applications a on a.user_id = p.agent_id and a.status = 'approved'
where p.status in ('approved','rented','sold') and pr.status = 'active';

create view public.public_reviews as
select r.id, pa.agent_code, split_part(trim(r.reviewer_name), ' ', 1) as reviewer_first_name,
  r.rating, r.comment, r.created_at
from public.agent_reviews r join public.public_agents pa on pa.id = r.agent_id
where r.verified;

grant select on public.public_agents, public.public_properties, public.public_reviews to anon, authenticated;
revoke all on public.agent_stats from anon, authenticated;

-- ---------------------------------------------------------------------
-- 6. Row-level security
-- ---------------------------------------------------------------------
alter table public.property_owner_details enable row level security;
alter table public.transactions enable row level security;
alter table public.agent_reviews enable row level security;
alter table public.agent_weekly_reports enable row level security;
alter table public.weekly_reports enable row level security;
alter table public.site_settings enable row level security;

-- profiles
drop policy if exists profiles_read_self_admin on public.profiles;
drop policy if exists profiles_read_self_staff on public.profiles;
create policy profiles_read_self_staff on public.profiles for select to authenticated
  using (id = auth.uid() or public.rc_is_staff());

-- agent applications (ops reads/decides; applicant reads/edits own)
drop policy if exists apps_read_owner_admin on public.agent_applications;
drop policy if exists apps_insert_self on public.agent_applications;
drop policy if exists apps_update_owner_admin on public.agent_applications;
drop policy if exists apps_read_owner_ops on public.agent_applications;
drop policy if exists apps_update_owner on public.agent_applications;
create policy apps_read_owner_ops on public.agent_applications for select to authenticated
  using (user_id = auth.uid() or public.rc_is_ops());
create policy apps_insert_self on public.agent_applications for insert to authenticated
  with check (user_id = auth.uid() and agreed_conduct = true and status = 'submitted');
create policy apps_update_owner on public.agent_applications for update to authenticated
  using (user_id = auth.uid() and status = 'needs_information')
  with check (user_id = auth.uid() and status = 'submitted' and agreed_conduct = true);

-- properties
drop policy if exists properties_public_approved_read on public.properties;
drop policy if exists properties_agent_insert on public.properties;
drop policy if exists properties_agent_update on public.properties;
drop policy if exists properties_read_own_staff on public.properties;
create policy properties_read_own_staff on public.properties for select to authenticated
  using (agent_id = auth.uid() or public.rc_is_staff());
create policy properties_agent_insert on public.properties for insert to authenticated
  with check (agent_id = auth.uid() and public.rc_is_agent() and status in ('draft','pending_review'));
-- an agent may edit own listing; anything live goes back to review (status must end as draft / pending_review / needs_changes)
create policy properties_agent_update on public.properties for update to authenticated
  using (agent_id = auth.uid() and public.rc_is_agent() and status in ('draft','pending_review','needs_changes','approved'))
  with check (agent_id = auth.uid() and public.rc_is_agent() and status in ('draft','pending_review'));

-- verification records
drop policy if exists verification_admin_or_owner_read on public.verification_records;
drop policy if exists verification_staff_or_owner_read on public.verification_records;
create policy verification_staff_or_owner_read on public.verification_records for select to authenticated
  using (public.rc_is_staff() or exists (select 1 from public.properties p where p.id = property_id and p.agent_id = auth.uid()));

-- audit log: admin only
drop policy if exists audit_admin_read on public.audit_log;
create policy audit_admin_read on public.audit_log for select to authenticated using (public.rc_is_admin());

-- enquiries, inspections, complaints: public submissions go through functions (section 8)
drop policy if exists inquiries_insert_any on public.property_inquiries;
drop policy if exists inquiries_admin_read on public.property_inquiries;
drop policy if exists inquiries_read_agent_staff on public.property_inquiries;
drop policy if exists inquiries_update_agent_staff on public.property_inquiries;
create policy inquiries_read_agent_staff on public.property_inquiries for select to authenticated
  using (public.rc_is_staff() or exists (select 1 from public.properties p where p.id = property_id and p.agent_id = auth.uid()));
create policy inquiries_update_agent_staff on public.property_inquiries for update to authenticated
  using (public.rc_is_staff() or exists (select 1 from public.properties p where p.id = property_id and p.agent_id = auth.uid()))
  with check (true);

drop policy if exists inspections_insert_any on public.inspection_bookings;
drop policy if exists inspections_read_owner_admin on public.inspection_bookings;
drop policy if exists inspections_read_agent_staff on public.inspection_bookings;
drop policy if exists inspections_update_agent_staff on public.inspection_bookings;
create policy inspections_read_agent_staff on public.inspection_bookings for select to authenticated
  using (customer_id = auth.uid() or agent_id = auth.uid() or public.rc_is_staff());
create policy inspections_update_agent_staff on public.inspection_bookings for update to authenticated
  using (agent_id = auth.uid() or public.rc_is_staff()) with check (true);

drop policy if exists complaints_insert_any on public.complaints;
drop policy if exists complaints_admin_manage on public.complaints;
drop policy if exists complaints_staff_read on public.complaints;
drop policy if exists complaints_staff_update on public.complaints;
create policy complaints_staff_read on public.complaints for select to authenticated using (public.rc_is_staff());
create policy complaints_staff_update on public.complaints for update to authenticated using (public.rc_is_staff()) with check (true);

-- commissions: agent reads own; operations/admin read all; writes only through functions
drop policy if exists commissions_admin_manage on public.commissions;
drop policy if exists commissions_read_own_ops on public.commissions;
create policy commissions_read_own_ops on public.commissions for select to authenticated
  using (agent_id = auth.uid() or public.rc_is_ops());

-- owner details: the listing's agent and operations staff only
drop policy if exists owner_details_select on public.property_owner_details;
drop policy if exists owner_details_insert on public.property_owner_details;
drop policy if exists owner_details_update on public.property_owner_details;
create policy owner_details_select on public.property_owner_details for select to authenticated
  using (public.rc_is_ops() or exists (select 1 from public.properties p where p.id = property_id and p.agent_id = auth.uid()));
create policy owner_details_insert on public.property_owner_details for insert to authenticated
  with check (exists (select 1 from public.properties p where p.id = property_id and p.agent_id = auth.uid()));
create policy owner_details_update on public.property_owner_details for update to authenticated
  using (exists (select 1 from public.properties p where p.id = property_id and p.agent_id = auth.uid()))
  with check (exists (select 1 from public.properties p where p.id = property_id and p.agent_id = auth.uid()));

-- transactions: agent reads own; ops/admin read all
drop policy if exists transactions_read on public.transactions;
create policy transactions_read on public.transactions for select to authenticated
  using (agent_id = auth.uid() or public.rc_is_ops());

-- reviews: staff read and moderate
drop policy if exists reviews_staff_read on public.agent_reviews;
drop policy if exists reviews_staff_update on public.agent_reviews;
drop policy if exists reviews_staff_delete on public.agent_reviews;
create policy reviews_staff_read on public.agent_reviews for select to authenticated using (public.rc_is_staff());
create policy reviews_staff_update on public.agent_reviews for update to authenticated using (public.rc_is_staff()) with check (true);
create policy reviews_staff_delete on public.agent_reviews for delete to authenticated using (public.rc_is_staff());

-- agent weekly reports
drop policy if exists weekly_agent_read on public.agent_weekly_reports;
drop policy if exists weekly_agent_insert on public.agent_weekly_reports;
drop policy if exists weekly_agent_update on public.agent_weekly_reports;
create policy weekly_agent_read on public.agent_weekly_reports for select to authenticated
  using (agent_id = auth.uid() or public.rc_is_ops());
create policy weekly_agent_insert on public.agent_weekly_reports for insert to authenticated
  with check (agent_id = auth.uid() and public.rc_is_agent());
create policy weekly_agent_update on public.agent_weekly_reports for update to authenticated
  using (agent_id = auth.uid() and public.rc_is_agent()) with check (agent_id = auth.uid());

-- CEO weekly scorecard: admin only
drop policy if exists weekly_reports_admin on public.weekly_reports;
create policy weekly_reports_admin on public.weekly_reports for all to authenticated
  using (public.rc_is_admin()) with check (public.rc_is_admin());

-- site_settings: no policies on purpose (functions only)

-- ---------------------------------------------------------------------
-- 7. Table and column privileges (least privilege)
-- ---------------------------------------------------------------------
revoke all on public.profiles, public.agent_applications, public.properties, public.verification_records,
  public.audit_log, public.property_inquiries, public.inspection_bookings, public.complaints, public.commissions,
  public.property_owner_details, public.transactions, public.agent_reviews, public.agent_weekly_reports,
  public.weekly_reports, public.site_settings from anon, authenticated;

grant select on public.profiles, public.verification_records, public.audit_log, public.commissions,
  public.transactions, public.property_owner_details, public.agent_reviews, public.agent_weekly_reports,
  public.property_inquiries, public.inspection_bookings, public.complaints, public.weekly_reports to authenticated;
grant select on public.properties, public.agent_applications to authenticated;

grant insert (user_id, full_name, phone, whatsapp, operating_state, operating_areas, experience, references_text, id_document_path, agreed_conduct, status)
  on public.agent_applications to authenticated;
grant update (full_name, phone, whatsapp, operating_state, operating_areas, experience, references_text, id_document_path, agreed_conduct, status)
  on public.agent_applications to authenticated;

grant insert (agent_id, title, state, area, property_type, listing_type, category, bedrooms, bathrooms, price,
  agency_fee, caution_fee, legal_fee, land_size_sqm, land_title, features, description, photo_urls, status)
  on public.properties to authenticated;
grant update (title, state, area, property_type, listing_type, category, bedrooms, bathrooms, price,
  agency_fee, caution_fee, legal_fee, land_size_sqm, land_title, features, description, photo_urls, status)
  on public.properties to authenticated;

grant insert (property_id, relationship, owner_name, owner_phone, owner_email, owner_address, authorised, proof_paths)
  on public.property_owner_details to authenticated;
grant update (relationship, owner_name, owner_phone, owner_email, owner_address, authorised, proof_paths)
  on public.property_owner_details to authenticated;

grant update (status) on public.property_inquiries to authenticated;
grant update (status, notes) on public.inspection_bookings to authenticated;
grant update (status, resolution_note) on public.complaints to authenticated;
grant update (verified) on public.agent_reviews to authenticated;
grant delete on public.agent_reviews to authenticated;

grant insert (agent_id, week_start, new_properties_sourced, owner_contacts, authorisations_obtained, listings_submitted,
  inspections_attended, enquiries_handled, transactions_completed, problems) on public.agent_weekly_reports to authenticated;
grant update (new_properties_sourced, owner_contacts, authorisations_obtained, listings_submitted,
  inspections_attended, enquiries_handled, transactions_completed, problems) on public.agent_weekly_reports to authenticated;
grant insert, update, delete on public.weekly_reports to authenticated;
-- agents insert listings; the listing code default calls nextval as the agent
grant usage on sequence public.cv_property_seq to authenticated;

-- ---------------------------------------------------------------------
-- 8. Functions
-- ---------------------------------------------------------------------
-- 8.1 agent applications (operations or admin)
create or replace function public.review_application(p_id uuid, p_status text, p_note text default '') returns void
language plpgsql security definer set search_path = public as $$
declare a public.agent_applications%rowtype; prof public.profiles%rowtype;
begin
  if not public.rc_is_ops() then raise exception 'Operations or admin access required'; end if;
  if p_status not in ('under_review','needs_information','approved','rejected','suspended') then raise exception 'Invalid application status'; end if;
  select * into a from public.agent_applications where id = p_id for update;
  if not found then raise exception 'Application not found'; end if;
  if p_status in ('needs_information','rejected','suspended') and length(trim(coalesce(p_note,''))) = 0 then raise exception 'A decision note is required'; end if;
  select * into prof from public.profiles where id = a.user_id;
  if prof.role in ('admin','staff') then raise exception 'Staff accounts cannot be agents'; end if;
  update public.agent_applications set status = p_status, reviewer_note = trim(coalesce(p_note,'')), reviewed_by = auth.uid(), reviewed_at = now() where id = p_id;
  if p_status = 'approved' then
    update public.profiles set role = 'agent', status = 'active', full_name = a.full_name, phone = coalesce(phone, a.phone),
      location = coalesce(nullif(location,''), a.operating_state),
      agent_code = coalesce(agent_code, 'CV-AGT-' || lpad(nextval('public.cv_agent_seq')::text, 3, '0')),
      id_expires_at = now() + interval '1 year'
    where id = a.user_id;
  elsif p_status = 'suspended' then
    update public.profiles set status = 'suspended' where id = a.user_id;
  end if;
  insert into public.audit_log(actor_id, action, record_type, record_id, summary)
    values (auth.uid(), 'review_application', 'agent_application', p_id::text, jsonb_build_object('status', p_status, 'note', p_note));
end; $$;

-- 8.2 verification checks (operations or admin)
create or replace function public.add_verification(p_property uuid, p_label text, p_note text, p_recheck date default null) returns uuid
language plpgsql security definer set search_path = public as $$
declare rid uuid;
begin
  if not public.rc_is_ops() then raise exception 'Operations or admin access required'; end if;
  if p_label not in ('agent_identity_checked','property_viewed','owner_authority_checked','details_recently_confirmed') then raise exception 'Invalid verification label'; end if;
  if length(trim(coalesce(p_note,''))) < 3 then raise exception 'Evidence note is required'; end if;
  if not exists (select 1 from public.properties where id = p_property) then raise exception 'Property not found'; end if;
  insert into public.verification_records(property_id, label, verified_by, evidence_note, recheck_by)
    values (p_property, p_label, auth.uid(), trim(p_note), p_recheck) returning id into rid;
  insert into public.audit_log(actor_id, action, record_type, record_id, summary)
    values (auth.uid(), 'add_verification', 'property', p_property::text, jsonb_build_object('label', p_label, 'note', p_note));
  return rid;
end; $$;

-- 8.3 property review (operations or admin). Approval needs all four checks.
create or replace function public.review_property(p_id uuid, p_status text, p_note text default '') returns void
language plpgsql security definer set search_path = public as $$
begin
  if not public.rc_is_ops() then raise exception 'Operations or admin access required'; end if;
  if p_status not in ('under_review','approved','needs_changes','rejected','hidden') then raise exception 'Invalid property status'; end if;
  if p_status in ('needs_changes','rejected','hidden') and length(trim(coalesce(p_note,''))) = 0 then raise exception 'A decision note is required'; end if;
  if not exists (select 1 from public.properties where id = p_id) then raise exception 'Property not found'; end if;
  if p_status = 'approved' and (select count(distinct label) from public.verification_records where property_id = p_id) < 4 then
    raise exception 'Record all four required verification checks before approval';
  end if;
  update public.properties set status = p_status, reviewer_note = trim(coalesce(p_note,'')),
    published_at = case when p_status = 'approved' then coalesce(published_at, now()) else published_at end,
    last_confirmed_at = case when p_status = 'approved' then now() else last_confirmed_at end
  where id = p_id;
  insert into public.audit_log(actor_id, action, record_type, record_id, summary)
    values (auth.uid(), 'review_property', 'property', p_id::text, jsonb_build_object('status', p_status, 'note', p_note));
end; $$;

-- 8.4 closing and availability
create or replace function public.mark_closed(p_id uuid) returns void
language plpgsql security definer set search_path = public as $$
declare lt text;
begin
  select listing_type into lt from public.properties where id = p_id and agent_id = auth.uid() and status = 'approved';
  if lt is null or not public.rc_is_agent() then raise exception 'Only the assigned active agent can close an approved listing'; end if;
  update public.properties set status = case when lt = 'rent' then 'rented' else 'sold' end where id = p_id;
  insert into public.audit_log(actor_id, action, record_type, record_id, summary) values (auth.uid(), 'mark_closed', 'property', p_id::text, '{}'::jsonb);
end; $$;

create or replace function public.confirm_availability(p_id uuid) returns void
language plpgsql security definer set search_path = public as $$
begin
  if not exists (select 1 from public.properties where id = p_id and status = 'approved'
      and ((agent_id = auth.uid() and public.rc_is_agent()) or public.rc_is_ops())) then
    raise exception 'Not allowed, or the listing is not live';
  end if;
  update public.properties set last_confirmed_at = now() where id = p_id;
end; $$;

-- 8.5 own profile
create or replace function public.update_my_profile(p_phone text, p_location text, p_photo_url text) returns void
language plpgsql security definer set search_path = public as $$
begin
  if auth.uid() is null then raise exception 'Sign in first'; end if;
  update public.profiles set phone = nullif(trim(coalesce(p_phone,'')), ''), location = nullif(trim(coalesce(p_location,'')), ''),
    photo_url = nullif(trim(coalesce(p_photo_url,'')), '') where id = auth.uid();
end; $$;

-- 8.6 staff management (admin only; the main admin cannot be changed)
create or replace function public.set_staff_access(p_email text, p_access text) returns void
language plpgsql security definer set search_path = public, auth as $$
declare uid uuid; main_email text; cur public.profiles%rowtype; new_role text;
begin
  if not public.rc_is_admin() then raise exception 'Admin access required'; end if;
  if p_access not in ('admin','operations','marketing','none') then raise exception 'Invalid access level'; end if;
  select id into uid from auth.users where lower(email) = lower(trim(p_email));
  if uid is null then raise exception 'No account with that email. Ask the person to create an account first'; end if;
  select value into main_email from public.site_settings where key = 'main_admin_email';
  if main_email is not null and lower(main_email) = lower(trim(p_email)) then raise exception 'The main admin cannot be changed'; end if;
  if uid = auth.uid() then raise exception 'You cannot change your own access'; end if;
  select * into cur from public.profiles where id = uid;
  if not found then raise exception 'Profile not found'; end if;
  if p_access = 'admin' then
    update public.profiles set role = 'admin', staff_role = null, status = 'active',
      staff_code = coalesce(staff_code, 'CV-STF-' || lpad(nextval('public.cv_staff_seq')::text, 3, '0')),
      id_expires_at = coalesce(id_expires_at, now() + interval '1 year') where id = uid;
  elsif p_access in ('operations','marketing') then
    update public.profiles set role = 'staff', staff_role = p_access, status = 'active',
      staff_code = coalesce(staff_code, 'CV-STF-' || lpad(nextval('public.cv_staff_seq')::text, 3, '0')),
      id_expires_at = coalesce(id_expires_at, now() + interval '1 year') where id = uid;
  else
    new_role := case when exists (select 1 from public.agent_applications where user_id = uid and status = 'approved') and cur.agent_code is not null then 'agent' else 'customer' end;
    update public.profiles set role = new_role, staff_role = null where id = uid;
  end if;
  insert into public.audit_log(actor_id, action, record_type, record_id, summary)
    values (auth.uid(), 'set_staff_access', 'profile', uid::text, jsonb_build_object('email', p_email, 'access', p_access));
end; $$;

create or replace function public.list_staff() returns table (id uuid, email text, full_name text, role text, staff_role text, staff_code text, status text)
language plpgsql stable security definer set search_path = public, auth as $$
begin
  if not public.rc_is_admin() then raise exception 'Admin access required'; end if;
  return query select p.id, u.email::text, p.full_name, p.role, p.staff_role, p.staff_code, p.status
    from public.profiles p join auth.users u on u.id = p.id where p.role in ('admin','staff') order by p.role, p.full_name;
end; $$;

-- 8.7 completed deals and commission (operations or admin)
create or replace function public.complete_transaction(p_property uuid, p_customer text, p_phone text, p_deal_value numeric,
  p_commission numeric, p_agent_share numeric, p_notes text default '') returns uuid
language plpgsql security definer set search_path = public as $$
declare prop public.properties%rowtype; tid uuid;
begin
  if not public.rc_is_ops() then raise exception 'Operations or admin access required'; end if;
  select * into prop from public.properties where id = p_property for update;
  if not found then raise exception 'Property not found'; end if;
  if prop.status not in ('approved','rented','sold') then raise exception 'Only a live listing can be completed'; end if;
  if length(trim(coalesce(p_customer,''))) < 2 then raise exception 'Customer name is required'; end if;
  if p_deal_value is null or p_deal_value <= 0 then raise exception 'Deal value must be above zero'; end if;
  if p_commission is null or p_commission < 0 or p_agent_share is null or p_agent_share < 0 or p_agent_share > p_commission then
    raise exception 'Agent share cannot be more than the commission';
  end if;
  insert into public.transactions(property_id, agent_id, kind, customer_name, customer_phone, deal_value, commission_amount, agent_share, notes, recorded_by)
    values (p_property, prop.agent_id, prop.listing_type, trim(p_customer), trim(coalesce(p_phone,'')), p_deal_value, p_commission, p_agent_share, nullif(trim(coalesce(p_notes,'')), ''), auth.uid())
    returning id into tid;
  insert into public.commissions(agent_id, property_id, amount, status, transaction_id, notes)
    values (prop.agent_id, p_property, p_agent_share, 'due', tid, nullif(trim(coalesce(p_notes,'')), ''));
  update public.properties set status = case when prop.listing_type = 'rent' then 'rented' else 'sold' end where id = p_property;
  insert into public.audit_log(actor_id, action, record_type, record_id, summary)
    values (auth.uid(), 'complete_transaction', 'transaction', tid::text, jsonb_build_object('property', p_property, 'deal_value', p_deal_value, 'commission', p_commission, 'agent_share', p_agent_share));
  return tid;
end; $$;

create or replace function public.mark_commission_paid(p_id uuid, p_reference text) returns void
language plpgsql security definer set search_path = public as $$
begin
  if not public.rc_is_admin() then raise exception 'Admin access required'; end if;
  if length(trim(coalesce(p_reference,''))) < 3 then raise exception 'A payment reference is required'; end if;
  update public.commissions set status = 'paid', paid_at = now(), reference = trim(p_reference) where id = p_id and status in ('pending','due');
  if not found then raise exception 'Commission not found or already settled'; end if;
  insert into public.audit_log(actor_id, action, record_type, record_id, summary)
    values (auth.uid(), 'mark_commission_paid', 'commission', p_id::text, jsonb_build_object('reference', p_reference));
end; $$;

-- 8.8 an agent's own numbers (agent_stats is not public)
create or replace function public.my_agent_stats() returns table (approved_listings int, completed_transactions int, avg_rating numeric, review_count int, badge text)
language sql stable security definer set search_path = public as $$
  select s.approved_listings, s.completed_transactions, s.avg_rating, s.review_count,
    public.rc_badge(s.approved_listings, s.completed_transactions, s.avg_rating)
  from public.agent_stats s where s.agent_id = auth.uid();
$$;

-- 8.9 public ID verification (QR code page). Never returns phone, email, address or documents.
create or replace function public.verify_id(p_code text)
returns table (full_name text, photo_url text, id_code text, category text, department text, status text, expires_at timestamptz, badge text)
language plpgsql stable security definer set search_path = public as $$
declare pr public.profiles%rowtype; st text; cat text; dept text; bdg text;
begin
  select * into pr from public.profiles where upper(agent_code) = upper(trim(p_code)) or upper(staff_code) = upper(trim(p_code)) limit 1;
  if not found then return; end if;
  if upper(pr.staff_code) = upper(trim(p_code)) then
    cat := 'Staff';
    dept := case when pr.role = 'admin' then 'Management' when pr.staff_role = 'operations' then 'Operations' when pr.staff_role = 'marketing' then 'Marketing' else null end;
    st := case when pr.role not in ('admin','staff') or dept is null then 'invalid' when pr.status <> 'active' then 'suspended'
               when pr.id_expires_at is not null and pr.id_expires_at < now() then 'expired' else 'valid' end;
  else
    cat := 'Agent';
    st := case when pr.role <> 'agent' then 'invalid' when pr.status <> 'active' then 'suspended'
               when pr.id_expires_at is not null and pr.id_expires_at < now() then 'expired' else 'valid' end;
    if st = 'valid' then
      select public.rc_badge(s.approved_listings, s.completed_transactions, s.avg_rating) into bdg from public.agent_stats s where s.agent_id = pr.id;
    end if;
  end if;
  return query select pr.full_name, pr.photo_url, coalesce(pr.agent_code, pr.staff_code), cat, dept, st, pr.id_expires_at, bdg;
end; $$;

-- 8.10 public submissions (validated, saved as records, simple spam guard)
create or replace function public.cv_clean_phone(p text) returns text language sql immutable as $$
  select regexp_replace(coalesce(p,''), '[^0-9+]', '', 'g');
$$;

create or replace function public.submit_enquiry(p_property uuid, p_name text, p_phone text, p_email text, p_message text) returns void
language plpgsql security definer set search_path = public as $$
declare ph text := public.cv_clean_phone(p_phone);
begin
  if length(trim(coalesce(p_name,''))) not between 2 and 100 then raise exception 'Please enter your name'; end if;
  if length(ph) < 7 or length(ph) > 16 then raise exception 'Please enter a valid phone number'; end if;
  if length(trim(coalesce(p_message,''))) not between 5 and 1000 then raise exception 'Please write a short message (5 to 1000 characters)'; end if;
  if p_email is not null and length(p_email) > 0 and (length(p_email) > 150 or p_email !~ '^[^@\s]+@[^@\s]+\.[^@\s]+$') then raise exception 'That email address does not look right'; end if;
  if p_property is not null and not exists (select 1 from public.properties where id = p_property and status in ('approved','rented','sold')) then raise exception 'That property is no longer listed'; end if;
  if (select count(*) from public.property_inquiries where customer_phone = ph and created_at > now() - interval '1 hour') >= 5 then raise exception 'Too many requests from this number. Please try again later'; end if;
  insert into public.property_inquiries(property_id, customer_id, customer_name, customer_email, customer_phone, message, status)
    values (p_property, auth.uid(), trim(p_name), nullif(trim(coalesce(p_email,'')), ''), ph, trim(p_message), 'new');
end; $$;

create or replace function public.submit_inspection(p_property uuid, p_name text, p_phone text, p_requested_at timestamptz, p_notes text default '') returns void
language plpgsql security definer set search_path = public as $$
declare ph text := public.cv_clean_phone(p_phone);
begin
  if length(trim(coalesce(p_name,''))) not between 2 and 100 then raise exception 'Please enter your name'; end if;
  if length(ph) < 7 or length(ph) > 16 then raise exception 'Please enter a valid phone number'; end if;
  if p_requested_at is null or p_requested_at < now() - interval '1 hour' or p_requested_at > now() + interval '90 days' then raise exception 'Choose a date and time within the next 90 days'; end if;
  if length(coalesce(p_notes,'')) > 500 then raise exception 'Notes are too long (500 characters at most)'; end if;
  if not exists (select 1 from public.properties where id = p_property and status = 'approved') then raise exception 'That property is not available for inspection'; end if;
  if (select count(*) from public.inspection_bookings where customer_phone = ph and created_at > now() - interval '1 hour') >= 3 then raise exception 'Too many requests from this number. Please try again later'; end if;
  insert into public.inspection_bookings(property_id, customer_id, customer_name, customer_phone, requested_at, notes, status)
    values (p_property, auth.uid(), trim(p_name), ph, p_requested_at, nullif(trim(coalesce(p_notes,'')), ''), 'requested');
end; $$;

create or replace function public.submit_complaint(p_property uuid, p_name text, p_phone text, p_category text, p_description text) returns text
language plpgsql security definer set search_path = public as $$
declare ph text := public.cv_clean_phone(p_phone); ref text;
begin
  if length(trim(coalesce(p_category,''))) not between 2 and 80 then raise exception 'Please choose a category'; end if;
  if length(trim(coalesce(p_description,''))) not between 10 and 2000 then raise exception 'Please describe the problem (10 to 2000 characters)'; end if;
  if length(coalesce(p_name,'')) > 100 then raise exception 'Name is too long'; end if;
  if length(ph) > 0 and (length(ph) < 7 or length(ph) > 16) then raise exception 'Please enter a valid phone number'; end if;
  if (select count(*) from public.complaints where coalesce(reporter_phone,'') = ph and ph <> '' and created_at > now() - interval '1 hour') >= 5 then raise exception 'Too many requests from this number. Please try again later'; end if;
  insert into public.complaints(property_id, reporter_id, reporter_name, reporter_phone, category, description, status)
    values (p_property, auth.uid(), nullif(trim(coalesce(p_name,'')), ''), nullif(ph, ''), trim(p_category), trim(p_description), 'received')
    returning ref_code into ref;
  return ref;
end; $$;

create or replace function public.submit_review(p_agent_code text, p_name text, p_phone text, p_rating integer, p_comment text) returns void
language plpgsql security definer set search_path = public as $$
declare aid uuid; ph text := public.cv_clean_phone(p_phone);
begin
  select id into aid from public.public_agents where upper(agent_code) = upper(trim(p_agent_code));
  if aid is null then raise exception 'Agent not found'; end if;
  if length(trim(coalesce(p_name,''))) not between 2 and 80 then raise exception 'Please enter your name'; end if;
  if length(ph) < 7 or length(ph) > 16 then raise exception 'Please enter the phone number you used with the agent (staff use it to verify your review)'; end if;
  if p_rating is null or p_rating not between 1 and 5 then raise exception 'Choose a rating from 1 to 5'; end if;
  if length(coalesce(p_comment,'')) > 1000 then raise exception 'Comment is too long (1000 characters at most)'; end if;
  if exists (select 1 from public.agent_reviews where agent_id = aid and reviewer_phone = ph and created_at > now() - interval '30 days') then raise exception 'You have already reviewed this agent recently'; end if;
  insert into public.agent_reviews(agent_id, reviewer_name, reviewer_phone, rating, comment, verified)
    values (aid, trim(p_name), ph, p_rating, trim(coalesce(p_comment,'')), false);
end; $$;

-- 8.11 function permissions
revoke execute on all functions in schema public from public, anon, authenticated;
grant execute on function public.rc_staff_role(), public.rc_is_staff(), public.rc_is_ops(), public.rc_is_admin(), public.rc_is_agent() to authenticated;
grant execute on function public.rc_badge(integer, integer, numeric) to anon, authenticated;
grant execute on function public.review_application(uuid, text, text) to authenticated;
grant execute on function public.add_verification(uuid, text, text, date) to authenticated;
grant execute on function public.review_property(uuid, text, text) to authenticated;
grant execute on function public.mark_rented(uuid) to authenticated;
grant execute on function public.mark_closed(uuid) to authenticated;
grant execute on function public.confirm_availability(uuid) to authenticated;
grant execute on function public.update_my_profile(text, text, text) to authenticated;
grant execute on function public.set_staff_access(text, text) to authenticated;
grant execute on function public.list_staff() to authenticated;
grant execute on function public.complete_transaction(uuid, text, text, numeric, numeric, numeric, text) to authenticated;
grant execute on function public.mark_commission_paid(uuid, text) to authenticated;
grant execute on function public.my_agent_stats() to authenticated;
grant execute on function public.verify_id(text) to anon, authenticated;
grant execute on function public.submit_enquiry(uuid, text, text, text, text) to anon, authenticated;
grant execute on function public.submit_inspection(uuid, text, text, timestamptz, text) to anon, authenticated;
grant execute on function public.submit_complaint(uuid, text, text, text, text) to anon, authenticated;
grant execute on function public.submit_review(text, text, text, integer, text) to anon, authenticated;

-- ---------------------------------------------------------------------
-- 9. Storage: photos (public), owner documents and ID documents (private)
-- ---------------------------------------------------------------------
insert into storage.buckets(id, name, public, file_size_limit, allowed_mime_types)
  values ('owner-docs', 'owner-docs', false, 5242880, array['image/jpeg','image/png','application/pdf'])
  on conflict (id) do nothing;

drop policy if exists owner_docs_agent_upload on storage.objects;
drop policy if exists owner_docs_read on storage.objects;
create policy owner_docs_agent_upload on storage.objects for insert to authenticated
  with check (bucket_id = 'owner-docs' and (storage.foldername(name))[1] = auth.uid()::text and public.rc_is_agent());
create policy owner_docs_read on storage.objects for select to authenticated
  using (bucket_id = 'owner-docs' and ((storage.foldername(name))[1] = auth.uid()::text or public.rc_is_ops()));

drop policy if exists agent_docs_admin_read on storage.objects;
drop policy if exists agent_docs_ops_read on storage.objects;
create policy agent_docs_ops_read on storage.objects for select to authenticated
  using (bucket_id = 'agent-docs' and public.rc_is_ops());

drop policy if exists property_photos_agent_upload on storage.objects;
drop policy if exists property_photos_staff_upload on storage.objects;
drop policy if exists property_photos_owner_delete on storage.objects;
create policy property_photos_agent_upload on storage.objects for insert to authenticated
  with check (bucket_id = 'property-photos' and (storage.foldername(name))[1] = auth.uid()::text and (public.rc_is_agent() or public.rc_is_staff()));
create policy property_photos_owner_delete on storage.objects for delete to authenticated
  using (bucket_id = 'property-photos' and (storage.foldername(name))[1] = auth.uid()::text);

-- ---------------------------------------------------------------------
-- 10. After running: name the main admin (replace the email, then run these two lines)
-- ---------------------------------------------------------------------
-- insert into public.site_settings(key, value) values ('main_admin_email', 'YOUR_ADMIN_EMAIL') on conflict (key) do update set value = excluded.value;
-- update public.profiles set role = 'admin', status = 'active', staff_code = coalesce(staff_code, 'CV-STF-' || lpad(nextval('public.cv_staff_seq')::text, 3, '0')) where id = (select id from auth.users where lower(email) = lower('YOUR_ADMIN_EMAIL'));
