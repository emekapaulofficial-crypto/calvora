-- =====================================================================
-- CALVORA RELEASE 2: landlords, customer CRM, agent subscriptions,
-- finance dashboard and special agent awards.
-- Run AFTER calvora-upgrade.sql and calvora-stage2.sql. Safe to run more than once.
-- =====================================================================

create sequence if not exists public.cv_landlord_seq;

-- 1. LANDLORDS -------------------------------------------------------
create table if not exists public.landlords (
  id uuid primary key default gen_random_uuid(),
  landlord_code text unique,
  full_name text not null check (length(trim(full_name)) >= 2),
  phone text not null default '',
  email text,
  address text not null default '',
  area text not null default '',
  source text not null default 'outreach' check (source in ('website','agent','referral','outreach','other')),
  status text not null default 'prospect' check (status in ('prospect','contacted','registered','inactive')),
  notes text not null default '',
  assigned_to uuid references public.profiles(id) on delete set null,
  created_by uuid references public.profiles(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
alter table public.properties add column if not exists landlord_id uuid references public.landlords(id) on delete set null;

create or replace function public.cv_landlord_code() returns trigger language plpgsql as $$
begin
  if new.landlord_code is null then new.landlord_code := 'CV-L-' || lpad(nextval('public.cv_landlord_seq')::text, 4, '0'); end if;
  new.updated_at := now(); return new;
end; $$;
drop trigger if exists landlords_code on public.landlords;
create trigger landlords_code before insert or update on public.landlords for each row execute function public.cv_landlord_code();

-- 2. CUSTOMER CRM ----------------------------------------------------
create table if not exists public.leads (
  id uuid primary key default gen_random_uuid(),
  full_name text not null check (length(trim(full_name)) >= 2),
  phone text not null default '',
  email text,
  interest text not null default 'rent' check (interest in ('rent','buy','land','other')),
  budget numeric check (budget is null or budget >= 0),
  preferred_area text not null default '',
  source text not null default 'website' check (source in ('website','whatsapp','facebook','instagram','tiktok','referral','walk_in','phone_call','other')),
  status text not null default 'new' check (status in ('new','contacted','inspection_booked','negotiating','won','lost')),
  assigned_to uuid references public.profiles(id) on delete set null,
  next_follow_up date,
  lost_reason text not null default '',
  property_id uuid references public.properties(id) on delete set null,
  enquiry_id uuid unique references public.property_inquiries(id) on delete set null,
  notes text not null default '',
  created_by uuid references public.profiles(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists leads_status_idx on public.leads(status);
create index if not exists leads_followup_idx on public.leads(next_follow_up);
create table if not exists public.lead_notes (
  id uuid primary key default gen_random_uuid(),
  lead_id uuid not null references public.leads(id) on delete cascade,
  author_id uuid references public.profiles(id) on delete set null,
  note text not null check (length(trim(note)) >= 1),
  created_at timestamptz not null default now()
);
create or replace function public.cv_touch() returns trigger language plpgsql as $$ begin new.updated_at := now(); return new; end; $$;
drop trigger if exists leads_touch on public.leads;
create trigger leads_touch before update on public.leads for each row execute function public.cv_touch();

-- 3. SUBSCRIPTIONS ---------------------------------------------------
create table if not exists public.subscription_plans (
  id uuid primary key default gen_random_uuid(),
  name text not null unique check (length(trim(name)) >= 2),
  price_monthly numeric not null check (price_monthly >= 0),
  description text not null default '',
  active boolean not null default true,
  created_at timestamptz not null default now()
);
create table if not exists public.agent_subscriptions (
  id uuid primary key default gen_random_uuid(),
  agent_id uuid not null references public.profiles(id) on delete cascade,
  plan_id uuid not null references public.subscription_plans(id) on delete restrict,
  status text not null default 'active' check (status in ('active','paused','cancelled')),
  starts_on date not null default current_date,
  renews_on date not null default (current_date + 30),
  created_at timestamptz not null default now()
);
create unique index if not exists one_live_sub_per_agent on public.agent_subscriptions(agent_id) where status in ('active','paused');
create table if not exists public.subscription_payments (
  id uuid primary key default gen_random_uuid(),
  subscription_id uuid not null references public.agent_subscriptions(id) on delete cascade,
  agent_id uuid not null references public.profiles(id) on delete cascade,
  amount numeric not null check (amount > 0),
  paid_on date not null default current_date,
  period_start date not null,
  period_end date not null,
  reference text not null check (length(trim(reference)) >= 3),
  recorded_by uuid references public.profiles(id) on delete set null,
  created_at timestamptz not null default now()
);

-- 4. FINANCE (manual entries; commissions and subscriptions are read from their own tables) ----
create table if not exists public.finance_entries (
  id uuid primary key default gen_random_uuid(),
  entry_date date not null default current_date,
  kind text not null check (kind in ('income','expense')),
  category text not null check (length(trim(category)) >= 2),
  amount numeric not null check (amount > 0),
  description text not null default '',
  reference text not null default '',
  created_by uuid references public.profiles(id) on delete set null,
  created_at timestamptz not null default now()
);
create index if not exists finance_date_idx on public.finance_entries(entry_date);

-- 5. SPECIAL AWARDS --------------------------------------------------
create table if not exists public.agent_awards (
  id uuid primary key default gen_random_uuid(),
  agent_id uuid not null references public.profiles(id) on delete cascade,
  award text not null check (award in ('Verified Listing Specialist','Customer Service Star','Top Performer','Fast Responder','Trusted Partner')),
  period text not null default '',
  note text not null default '',
  awarded_by uuid references public.profiles(id) on delete set null,
  awarded_at timestamptz not null default now(),
  unique (agent_id, award, period)
);

-- ROW LEVEL SECURITY --------------------------------------------------
alter table public.landlords enable row level security;
alter table public.leads enable row level security;
alter table public.lead_notes enable row level security;
alter table public.subscription_plans enable row level security;
alter table public.agent_subscriptions enable row level security;
alter table public.subscription_payments enable row level security;
alter table public.finance_entries enable row level security;
alter table public.agent_awards enable row level security;

drop policy if exists lead_notes_read on public.lead_notes;
create policy lead_notes_read on public.lead_notes for select to authenticated using (public.rc_is_staff());
drop policy if exists lead_notes_add on public.lead_notes;
create policy lead_notes_add on public.lead_notes for insert to authenticated with check (public.rc_is_staff() and author_id = auth.uid());
drop policy if exists plans_read on public.subscription_plans;
create policy plans_read on public.subscription_plans for select to authenticated using (public.rc_is_admin() or (active and public.rc_is_agent()));
drop policy if exists plans_admin on public.subscription_plans;
create policy plans_admin on public.subscription_plans for all to authenticated using (public.rc_is_admin()) with check (public.rc_is_admin());
drop policy if exists subs_read on public.agent_subscriptions;
create policy subs_read on public.agent_subscriptions for select to authenticated using (agent_id = auth.uid() or public.rc_is_admin());
drop policy if exists subs_admin on public.agent_subscriptions;
create policy subs_admin on public.agent_subscriptions for all to authenticated using (public.rc_is_admin()) with check (public.rc_is_admin());
drop policy if exists subpay_read on public.subscription_payments;
create policy subpay_read on public.subscription_payments for select to authenticated using (agent_id = auth.uid() or public.rc_is_admin());
drop policy if exists finance_admin on public.finance_entries;
create policy finance_admin on public.finance_entries for all to authenticated using (public.rc_is_admin()) with check (public.rc_is_admin());
drop policy if exists awards_read on public.agent_awards;
create policy awards_read on public.agent_awards for select to authenticated using (agent_id = auth.uid() or public.rc_is_staff());

-- PRIVILEGES ----------------------------------------------------------
revoke all on public.landlords, public.leads, public.lead_notes, public.subscription_plans, public.agent_subscriptions,
  public.subscription_payments, public.finance_entries, public.agent_awards from anon, authenticated;
grant select, insert, update on public.landlords to authenticated;
grant delete on public.landlords to authenticated;
grant select, insert, update, delete on public.leads to authenticated;
grant select, insert on public.lead_notes to authenticated;
grant select, insert, update, delete on public.subscription_plans to authenticated;
grant select, insert, update, delete on public.agent_subscriptions to authenticated;
grant select on public.subscription_payments to authenticated;
grant select, insert, update, delete on public.finance_entries to authenticated;
grant select, delete on public.agent_awards to authenticated;
-- delete on landlords/leads is limited to the admin by policy
drop policy if exists landlords_rw on public.landlords; drop policy if exists landlords_ins on public.landlords;
drop policy if exists landlords_upd on public.landlords; drop policy if exists landlords_del on public.landlords;
create policy landlords_rw on public.landlords for select to authenticated using (public.rc_is_staff());
create policy landlords_ins on public.landlords for insert to authenticated with check (public.rc_is_staff());
create policy landlords_upd on public.landlords for update to authenticated using (public.rc_is_staff()) with check (public.rc_is_staff());
create policy landlords_del on public.landlords for delete to authenticated using (public.rc_is_admin());
drop policy if exists leads_sel on public.leads; drop policy if exists leads_ins on public.leads;
drop policy if exists leads_upd on public.leads; drop policy if exists leads_del on public.leads;
create policy leads_sel on public.leads for select to authenticated using (public.rc_is_staff());
create policy leads_ins on public.leads for insert to authenticated with check (public.rc_is_staff());
create policy leads_upd on public.leads for update to authenticated using (public.rc_is_staff()) with check (public.rc_is_staff());
create policy leads_del on public.leads for delete to authenticated using (public.rc_is_admin());
drop policy if exists awards_del on public.agent_awards;
create policy awards_del on public.agent_awards for delete to authenticated using (public.rc_is_ops());

-- FUNCTIONS -----------------------------------------------------------
-- Public landlord registration form (no sign-in). Saved as a prospect for staff to follow up.
create or replace function public.submit_landlord_registration(p_name text, p_phone text, p_email text, p_area text, p_details text) returns void
language plpgsql security definer set search_path = public as $$
declare ph text := public.cv_clean_phone(p_phone); ex uuid;
begin
  if length(trim(coalesce(p_name,''))) not between 2 and 100 then raise exception 'Please enter your name'; end if;
  if length(ph) < 7 or length(ph) > 16 then raise exception 'Please enter a valid phone number'; end if;
  if length(trim(coalesce(p_area,''))) not between 2 and 120 then raise exception 'Please tell us where the property is'; end if;
  if length(coalesce(p_details,'')) > 1000 then raise exception 'Please keep the details under 1000 characters'; end if;
  if p_email is not null and length(p_email) > 0 and (length(p_email) > 150 or p_email !~ '^[^@\s]+@[^@\s]+\.[^@\s]+$') then raise exception 'That email address does not look right'; end if;
  if (select count(*) from public.landlords where phone = ph and created_at > now() - interval '1 hour') >= 3 then raise exception 'Too many requests from this number. Please try again later'; end if;
  select id into ex from public.landlords where phone = ph and status <> 'inactive' limit 1;
  if ex is not null then
    update public.landlords set notes = left(notes || E'\n' || to_char(now(),'YYYY-MM-DD') || ' (website): ' || trim(coalesce(p_area,'')) || ' ' || trim(coalesce(p_details,'')), 4000) where id = ex;
  else
    insert into public.landlords(full_name, phone, email, area, source, status, notes)
      values (trim(p_name), ph, nullif(trim(coalesce(p_email,'')),''), trim(p_area), 'website', 'prospect', trim(coalesce(p_details,'')));
  end if;
end; $$;

-- Link a property to its landlord (operations or admin).
create or replace function public.link_property_landlord(p_property uuid, p_landlord uuid) returns void
language plpgsql security definer set search_path = public as $$
begin
  if not public.rc_is_ops() then raise exception 'Operations or admin access required'; end if;
  if p_landlord is not null and not exists (select 1 from public.landlords where id = p_landlord) then raise exception 'Landlord not found'; end if;
  update public.properties set landlord_id = p_landlord where id = p_property;
  if not found then raise exception 'Property not found'; end if;
  insert into public.audit_log(actor_id, action, record_type, record_id, summary)
    values (auth.uid(), 'link_property_landlord', 'property', p_property::text, jsonb_build_object('landlord', p_landlord));
end; $$;

-- Turn a website enquiry into a CRM lead (once).
create or replace function public.convert_enquiry_to_lead(p_enquiry uuid) returns uuid
language plpgsql security definer set search_path = public as $$
declare q public.property_inquiries%rowtype; pt public.properties%rowtype; lid uuid;
begin
  if not public.rc_is_staff() then raise exception 'Staff access required'; end if;
  select * into q from public.property_inquiries where id = p_enquiry;
  if not found then raise exception 'Enquiry not found'; end if;
  select id into lid from public.leads where enquiry_id = p_enquiry;
  if lid is not null then return lid; end if;
  if q.property_id is not null then select * into pt from public.properties where id = q.property_id; end if;
  insert into public.leads(full_name, phone, email, interest, preferred_area, source, status, property_id, enquiry_id, notes, created_by, assigned_to, next_follow_up)
    values (q.customer_name, q.customer_phone, q.customer_email,
      case when pt.id is null then 'other' when pt.category = 'land' then 'land' when pt.listing_type = 'rent' then 'rent' else 'buy' end,
      coalesce(pt.area,''), 'website', 'new', q.property_id, q.id, q.message, auth.uid(), auth.uid(), current_date + 1)
    returning id into lid;
  if q.status = 'new' then update public.property_inquiries set status = 'contacted' where id = q.id; end if;
  return lid;
end; $$;

-- Subscription payments (admin). Moves the renewal date on by one month.
create or replace function public.record_subscription_payment(p_sub uuid, p_amount numeric, p_paid_on date, p_reference text) returns void
language plpgsql security definer set search_path = public as $$
declare s public.agent_subscriptions%rowtype;
begin
  if not public.rc_is_admin() then raise exception 'Admin access required'; end if;
  select * into s from public.agent_subscriptions where id = p_sub for update;
  if not found then raise exception 'Subscription not found'; end if;
  if s.status = 'cancelled' then raise exception 'This subscription is cancelled'; end if;
  if coalesce(p_amount,0) <= 0 then raise exception 'Enter the amount paid'; end if;
  if length(trim(coalesce(p_reference,''))) < 3 then raise exception 'A payment reference is required'; end if;
  insert into public.subscription_payments(subscription_id, agent_id, amount, paid_on, period_start, period_end, reference, recorded_by)
    values (s.id, s.agent_id, p_amount, coalesce(p_paid_on, current_date), s.renews_on, (s.renews_on + interval '1 month')::date, trim(p_reference), auth.uid());
  update public.agent_subscriptions set renews_on = (s.renews_on + interval '1 month')::date where id = s.id;
  insert into public.audit_log(actor_id, action, record_type, record_id, summary)
    values (auth.uid(), 'subscription_payment', 'agent_subscription', s.id::text, jsonb_build_object('amount', p_amount, 'reference', p_reference));
end; $$;

-- Finance summary for a date range, plus the last 6 months. Admin only.
create or replace function public.finance_summary(p_from date, p_to date) returns jsonb
language plpgsql stable security definer set search_path = public as $$
declare comm numeric; share numeric; subs numeric; oi numeric; ex numeric; due numeric; paid numeric; months jsonb; cats jsonb;
begin
  if not public.rc_is_admin() then raise exception 'Admin access required'; end if;
  if p_to < p_from then raise exception 'The end date is before the start date'; end if;
  select coalesce(sum(commission_amount),0), coalesce(sum(agent_share),0) into comm, share
    from public.transactions where status = 'completed' and completed_at::date between p_from and p_to;
  select coalesce(sum(amount),0) into subs from public.subscription_payments where paid_on between p_from and p_to;
  select coalesce(sum(amount) filter (where kind='income'),0), coalesce(sum(amount) filter (where kind='expense'),0) into oi, ex
    from public.finance_entries where entry_date between p_from and p_to;
  select coalesce(sum(amount) filter (where status in ('due','pending')),0), coalesce(sum(amount) filter (where status='paid' and paid_at::date between p_from and p_to),0)
    into due, paid from public.commissions;
  select coalesce(jsonb_agg(jsonb_build_object('month', to_char(m,'YYYY-MM'),
      'commission', (select coalesce(sum(commission_amount - agent_share),0) from public.transactions t where t.status='completed' and date_trunc('month', t.completed_at) = m),
      'subscriptions', (select coalesce(sum(amount),0) from public.subscription_payments sp where date_trunc('month', sp.paid_on) = m),
      'other_income', (select coalesce(sum(amount),0) from public.finance_entries f where f.kind='income' and date_trunc('month', f.entry_date) = m),
      'expenses', (select coalesce(sum(amount),0) from public.finance_entries f where f.kind='expense' and date_trunc('month', f.entry_date) = m)) order by m), '[]'::jsonb)
    into months from generate_series(date_trunc('month', current_date) - interval '5 months', date_trunc('month', current_date), interval '1 month') m;
  select coalesce(jsonb_agg(jsonb_build_object('category', category, 'kind', kind, 'total', total) order by total desc), '[]'::jsonb) into cats
    from (select category, kind, sum(amount) total from public.finance_entries where entry_date between p_from and p_to group by category, kind) x;
  return jsonb_build_object('from', p_from, 'to', p_to, 'commission_earned', comm, 'agent_share', share, 'subscription_income', subs,
    'other_income', oi, 'expenses', ex, 'net', comm - share + subs + oi - ex, 'commission_due_to_agents', due, 'commission_paid_out', paid,
    'months', months, 'categories', cats);
end; $$;

-- Awards (operations or admin). A period such as 2026-11 lets Top Performer repeat monthly.
create or replace function public.give_award(p_agent uuid, p_award text, p_period text, p_note text) returns void
language plpgsql security definer set search_path = public as $$
begin
  if not public.rc_is_ops() then raise exception 'Operations or admin access required'; end if;
  if not exists (select 1 from public.profiles where id = p_agent and role = 'agent') then raise exception 'Agent not found'; end if;
  if length(trim(coalesce(p_note,''))) < 3 then raise exception 'Please say why the award is given'; end if;
  insert into public.agent_awards(agent_id, award, period, note, awarded_by) values (p_agent, p_award, coalesce(trim(p_period),''), trim(p_note), auth.uid())
    on conflict (agent_id, award, period) do update set note = excluded.note, awarded_by = auth.uid(), awarded_at = now();
  insert into public.audit_log(actor_id, action, record_type, record_id, summary)
    values (auth.uid(), 'give_award', 'agent', p_agent::text, jsonb_build_object('award', p_award, 'period', p_period));
end; $$;

-- Public view of awards for live agents only.
drop view if exists public.public_agent_awards;
create view public.public_agent_awards as
select pa.agent_code, a.award, a.period, a.awarded_at
from public.agent_awards a join public.public_agents pa on pa.id = a.agent_id;
grant select on public.public_agent_awards to anon, authenticated;

-- Staff list of the leads that need a call today or earlier.
create or replace function public.crm_due_count() returns int language sql stable security definer set search_path = public as $$
  select case when public.rc_is_staff() then (select count(*)::int from public.leads where status not in ('won','lost') and next_follow_up is not null and next_follow_up <= current_date) else 0 end;
$$;

revoke all on function public.submit_landlord_registration(text,text,text,text,text), public.link_property_landlord(uuid,uuid),
  public.convert_enquiry_to_lead(uuid), public.record_subscription_payment(uuid,numeric,date,text), public.finance_summary(date,date),
  public.give_award(uuid,text,text,text), public.crm_due_count() from public;
grant execute on function public.submit_landlord_registration(text,text,text,text,text) to anon, authenticated;
grant execute on function public.link_property_landlord(uuid,uuid), public.convert_enquiry_to_lead(uuid), public.record_subscription_payment(uuid,numeric,date,text),
  public.finance_summary(date,date), public.give_award(uuid,text,text,text), public.crm_due_count() to authenticated;
