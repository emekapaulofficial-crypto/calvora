-- =====================================================================
-- CALVORA STAGE 2: extra functions for the agent portal and admin panel.
-- Run AFTER calvora-upgrade.sql. Safe to run more than once.
-- =====================================================================

-- Weekly CEO scorecard, built from real records. Admin only.
-- p_week is the Monday that starts the week. Expenses and issues come from what the CEO saved in weekly_reports.
create or replace function public.ceo_scorecard(p_week date) returns jsonb
language plpgsql stable security definer set search_path = public as $$
declare w0 timestamptz := p_week::timestamptz; w1 timestamptz := (p_week + 7)::timestamptz; wr public.weekly_reports%rowtype;
        rev numeric; share numeric;
begin
  if not public.rc_is_admin() then raise exception 'Admin access required'; end if;
  select * into wr from public.weekly_reports where week_start = p_week;
  select coalesce(sum(commission_amount),0), coalesce(sum(agent_share),0) into rev, share
    from public.transactions where status = 'completed' and completed_at >= w0 and completed_at < w1;
  return jsonb_build_object(
    'week_start', p_week,
    'active_agents', (select count(*) from public.profiles where role = 'agent' and status = 'active'),
    'active_properties', (select count(*) from public.properties where status = 'approved'),
    'enquiries', (select count(*) from public.property_inquiries where created_at >= w0 and created_at < w1),
    'inspections', (select count(*) from public.inspection_bookings where created_at >= w0 and created_at < w1),
    'transactions', (select count(*) from public.transactions where status = 'completed' and completed_at >= w0 and completed_at < w1),
    'revenue', rev, 'agent_share', share,
    'expenses', coalesce(wr.expenses, 0), 'issues', coalesce(wr.issues, ''));
end; $$;

-- Agent list with numbers for staff (agent_stats itself is not public).
create or replace function public.staff_agent_stats() returns table
 (agent_id uuid, full_name text, agent_code text, status text, location text, id_expires_at timestamptz,
  approved_listings int, completed_transactions int, avg_rating numeric, review_count int, badge text)
language plpgsql stable security definer set search_path = public as $$
begin
  if not public.rc_is_staff() then raise exception 'Staff access required'; end if;
  return query select p.id, p.full_name, p.agent_code, p.status, p.location, p.id_expires_at,
      s.approved_listings, s.completed_transactions, s.avg_rating, s.review_count,
      public.rc_badge(s.approved_listings, s.completed_transactions, s.avg_rating)
    from public.profiles p join public.agent_stats s on s.agent_id = p.id
    where p.role = 'agent' order by s.completed_transactions desc, s.approved_listings desc, p.full_name;
end; $$;

-- Renew an agent's or staff member's ID card for another year (operations or admin).
create or replace function public.renew_id(p_user uuid) returns void
language plpgsql security definer set search_path = public as $$
begin
  if not public.rc_is_ops() then raise exception 'Operations or admin access required'; end if;
  update public.profiles set id_expires_at = greatest(coalesce(id_expires_at, now()), now()) + interval '1 year'
    where id = p_user and role in ('agent','staff','admin');
  if not found then raise exception 'Person not found'; end if;
  insert into public.audit_log(actor_id, action, record_type, record_id, summary) values (auth.uid(), 'renew_id', 'profile', p_user::text, '{}'::jsonb);
end; $$;

-- An agent may delete their own listing while it is not live.
create or replace function public.delete_my_listing(p_id uuid) returns void
language plpgsql security definer set search_path = public as $$
begin
  if not public.rc_is_agent() then raise exception 'Agent access required'; end if;
  delete from public.properties where id = p_id and agent_id = auth.uid() and status in ('draft','needs_changes','rejected','pending_review');
  if not found then raise exception 'Only a listing that is not live can be deleted'; end if;
end; $$;

revoke execute on function public.ceo_scorecard(date), public.staff_agent_stats(), public.renew_id(uuid), public.delete_my_listing(uuid) from public, anon;
grant execute on function public.ceo_scorecard(date), public.staff_agent_stats(), public.renew_id(uuid), public.delete_my_listing(uuid) to authenticated;
