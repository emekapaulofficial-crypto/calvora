# Calvora Property Solutions: handbook

Do the four steps **in order**. Each step ends with a short check, so you know it worked before you move on.

## What has been built (all of it is in this folder)
| Part | What it gives you |
|---|---|
| Public website | Home, three catalogues (houses for rent, houses for sale, land), property pages, agent directory, agent profiles with reviews and awards, public ID check, about, contact, safety, complaints, legal, "List your property" with a landlord form |
| Agent portal (`agent.html`) | Sign up, apply, dashboard, add and edit listings with photos, enquiries, inspections, money, weekly report, printable ID card, subscription and awards |
| Staff panel (`admin.html`) | Agent applications, property checks and approval, enquiries, reviews, complaints, deals and commission, agent reports, customers (CRM), landlords, finance, subscriptions, weekly scorecard, staff, audit log |
| Database | Three SQL files: `supabase/calvora-upgrade.sql`, `calvora-stage2.sql`, `calvora-stage3.sql` |

Checked on a test copy of the database and in a browser. It has not yet been run on your live Supabase project, which is why Step 4 is a launch test.

---

## STEP 1: The database (Supabase)
Takes about 15 minutes.

1. In Supabase, take a backup first (Database > Backups, or export your tables).
2. Open **SQL Editor** > **New query**.
3. Paste the whole of `supabase/calvora-upgrade.sql` and click **Run**. Wait for "Success".
4. New query. Paste the whole of `supabase/calvora-stage2.sql` and **Run**.
5. New query. Paste the whole of `supabase/calvora-stage3.sql` and **Run**.

All three are safe to run again if something goes wrong. **Always run them in this order.**

**Check:** In Table Editor you should now see the tables `landlords`, `leads`, `subscription_plans`, `finance_entries`, `agent_awards` and others. If any file shows a red error, copy the error to me and stop here.

---

## STEP 2: Sign-in settings and your admin account (Supabase)
Takes about 15 minutes.

1. **Authentication > URL Configuration**: set **Site URL** to `https://www.calvora.com.ng`. Under **Redirect URLs** add `https://www.calvora.com.ng/agent.html` and `https://www.calvora.com.ng/admin.html`. (Password-reset emails use these.)
2. **Authentication > Providers > Email**: leave "Confirm email" on. People must click the link in their email before they can sign in.
3. **Authentication > SMTP**: add your own email sender before launch. Supabase's built-in sender sends only a few emails an hour.
4. Create your own account: **Authentication > Users > Add user**, with your email and a strong password.
5. In **SQL Editor** run these two lines, replacing `YOUR_ADMIN_EMAIL` in both places:
```sql
insert into public.site_settings(key, value) values ('main_admin_email', 'YOUR_ADMIN_EMAIL') on conflict (key) do update set value = excluded.value;
update public.profiles set role = 'admin', status = 'active', staff_code = coalesce(staff_code, 'CV-STF-' || lpad(nextval('public.cv_staff_seq')::text, 3, '0')) where id = (select id from auth.users where lower(email) = lower('YOUR_ADMIN_EMAIL'));
```
You are now the main admin (CEO). Nobody else can remove that.

**Check:** the second line says "UPDATE 1". If it says "UPDATE 0", the email does not match the account you created.

---

## STEP 3: Fill in your details and put the site online
Takes about 30 minutes.

1. Open `js/config.js`. Phone and WhatsApp are already +234 904 747 0202. Add the company email, address, opening hours, social links and bank details when you have them. Leave anything you do not have empty, because empty lines are not shown. Add the RC number only when CAC approves it. Never put a `service_role` key in any file.
2. Upload **the contents of this folder** (not the zip, not the `supabase` folder) to Cloudflare Pages or GitHub Pages. `index.html` must be at the top.
3. Point `www.calvora.com.ng` at it.

**Check:** open the site on your phone. The home page loads with the logo, and Rent, Buy and Land open (they will say "first listings coming soon" until you add some).

---

## STEP 4: Launch test and first people
Do this in order, with real accounts, before you tell anyone about the site.

1. **You (CEO):** open `/admin.html`, sign in. You should see every tab including Finance and Subscriptions.
2. **Staff:** each staff member creates an account on `/admin.html`. Then in *Staff* enter their email and choose Operations or Marketing.
   - Operations: approve agents and properties, record checks and deals, give awards.
   - Marketing: customers (CRM) and landlords, and view only elsewhere.
   - Only you: commission payment, finance, subscriptions, scorecard, staff, audit log.
3. **First agent:** a test agent signs up on `/agent.html`, uploads an ID and applies. Approve them under *Agent applications*. They get an ID like CV-AGT-001 and a one-year ID card.
4. **First listing:** the agent adds one listing with photos, the owner's details and proof of permission. Open it under *Properties*, record all four checks (each needs a note as evidence), then **Approve and publish**. It now shows on the public site.
5. **Customer side:** from your phone, send an enquiry and an inspection request on that property. They appear for the agent and under *Enquiries and visits*. Click **Add to CRM** to follow the customer up.
6. **A deal:** under *Deals and commission* record a completed deal. You then mark the commission paid with the bank reference.
7. **Public check:** open `/verify.html?id=CV-AGT-001`. It should show the agent as valid.
8. Delete the test records, then start real onboarding.

**Check:** every item above worked on the live site. If something does not, tell me which number and what you saw.

---

## Reference
- **Subscriptions** (CEO): create a plan, put an agent on it, record each payment with a bank reference. Agents see only their own. Keep this switched off until agents have seen the value of Calvora.
- **Finance** (CEO): commission comes from recorded deals and subscriptions from recorded payments, so never type those twice. Add other income and expenses by hand. Download any period as CSV.
- **Landlords**: website sign-ups from "List your property" arrive as prospects. Staff follow up, set them to Registered, and link their properties.
- **IDs:** agents CV-AGT-001, staff CV-STF-001, landlords CV-L-0001, properties CV-P-00001, complaints CV-C-00001.
- A listing goes live only after all four checks are recorded. The database enforces this, not just the page.
- Listings not re-confirmed for 30 days show "Availability Confirmation Pending" (`availabilityDays` in config.js).
- An agent's ID lasts one year. After that, the agent and their listings drop off the public site until staff renew it.
- Reviews stay hidden until staff verify them. Agent phone numbers are never shown publicly.
- Payments go by bank transfer to the official company account only.
